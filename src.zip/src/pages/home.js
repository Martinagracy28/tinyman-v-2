
import React from 'react';
  
const home = () => {
  return (
    <div
      style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '88vh'
      }}
    >
      <h1>Welcome to Element Swap</h1>
    </div>
  );
};
  
export default home;